# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8-100 compliant>

ADDON_ID = __package__  # Expected to be: 'bl_ext.blender_org.push_to_talk'
ADDON_SHORTNAME = "push_to_talk"

import datetime
import logging
import os
import platform
import re
import shlex
import shutil
import signal
import stat
import tarfile
import threading
import time
import urllib.request
import zipfile

from string import whitespace
from subprocess import Popen, PIPE, TimeoutExpired

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel


log = logging.getLogger(ADDON_SHORTNAME)

os_platform = platform.system()  # 'Linux', 'Windows'
supported_platforms = {'Linux', 'Windows'}

addon_dir = os.path.dirname(os.path.realpath(__file__))


def is_executable_file(path: str) -> bool:
    """Check if the given path is an existing, executable file."""
    if not path:
        return False
    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        return False
    if os_platform == 'Windows':
        return path.lower().endswith(('.exe', '.bat', '.cmd'))
    return os.access(path, os.X_OK)


def get_ffmpeg_path(context=None) -> str:
    """Resolve the ffmpeg executable path.

    Priority:
    1. Custom path in user preferences (if set and points to an executable file).
    2. Downloaded/bundled standalone binary in addon's bin/ folder.
    3. System PATH (via shutil.which("ffmpeg")).
    """
    # 1. Custom path from preferences
    try:
        ctx = context or (bpy.context if hasattr(bpy, "context") else None)
        if ctx and hasattr(ctx, "preferences") and ADDON_ID in ctx.preferences.addons:
            addon_prefs = ctx.preferences.addons[ADDON_ID].preferences
            if hasattr(addon_prefs, "ffmpeg_custom_path"):
                custom = os.path.expanduser(bpy.path.abspath(addon_prefs.ffmpeg_custom_path).strip())
                if custom and is_executable_file(custom):
                    return custom
    except Exception:
        pass

    # 2. Add-on managed binary in bin/
    bin_name = "ffmpeg.exe" if os_platform == 'Windows' else "ffmpeg"
    managed_bin = os.path.join(addon_dir, "bin", bin_name)
    if is_executable_file(managed_bin):
        return managed_bin

    # 3. System PATH
    system_path = shutil.which("ffmpeg")
    if system_path and is_executable_file(system_path):
        return system_path

    return ""

# Blender 4.4 renamed "Sequence" to "Strip" and deprecated "sequence_editor.sequences".
# This script needs to access one or the other depending on the Blender version.
USE_STRIPS = ((bpy.app.version[0] == 4 and bpy.app.version[1] >= 4) or bpy.app.version[0] > 4)

NO_DEVICE = ("no device found", "no audio device found", "Could not find a connected microphone")


# Audio Device & Quality Configuration #############################################################


def get_effective_bitrate_info(channels_str: str, sample_rate_str: str, bit_depth_str: str) -> str:
    """Calculate effective uncompressed PCM bitrate and formatted description string."""
    try:
        channels = int(channels_str)
        sample_rate = int(sample_rate_str)
        bit_depth = int(bit_depth_str)
        bitrate_kbps = (channels * sample_rate * bit_depth) // 1000
        depth_name = {16: "16-bit PCM", 24: "24-bit PCM", 32: "32-bit Float"}.get(bit_depth, f"{bit_depth}-bit")
        ch_name = "Mono" if channels == 1 else "Stereo"
        sr_name = f"{sample_rate / 1000:g} kHz"
        return f"{bitrate_kbps} kbps ({ch_name}, {depth_name}, {sr_name})"
    except Exception:
        return "Unknown"


def get_audio_devices_list_linux():
    """Get list of audio devices on Linux."""

    sound_cards = [("default", "Default Audio Device", "Default Audio Device (system default)")]

    # 1. First attempt: Query PipeWire / PulseAudio via pactl (handles modern Linux desktops)
    pactl_path = shutil.which("pactl")
    if pactl_path:
        try:
            proc = Popen([pactl_path, "list", "sources"], stdout=PIPE, stderr=PIPE, text=True)
            outs, _ = proc.communicate(timeout=2)
            if proc.returncode == 0:
                current_name = None
                for line in outs.splitlines():
                    line_s = line.strip()
                    if line_s.startswith("Name:"):
                        current_name = line_s.split("Name:", 1)[1].strip()
                    elif line_s.startswith("Description:"):
                        current_desc = line_s.split("Description:", 1)[1].strip()
                        if current_name and not current_name.endswith(".monitor"):
                            sound_cards.append((current_name, current_desc, current_name))
        except Exception as e:
            log.debug(f"PushToTalk: pactl query error: {e}")

    # 2. Second attempt: If only default was found, query ALSA capture devices via arecord -l
    if len(sound_cards) <= 1:
        arecord_path = shutil.which("arecord")
        if arecord_path:
            try:
                proc = Popen([arecord_path, "-l"], stdout=PIPE, stderr=PIPE, text=True)
                outs, _ = proc.communicate(timeout=2)
                if proc.returncode == 0:
                    for line in outs.splitlines():
                        # Example: card 1: Microphone [USB Condenser Microphone], device 0: USB Audio [USB Audio]
                        match = re.search(r"card\s+(\d+):\s+([^,]+)\[(.*?)\],\s+device\s+(\d+):\s+(.*)", line)
                        if match:
                            card_num, card_id, card_label, dev_num, dev_label = match.groups()
                            dev_id = f"plughw:CARD={card_id.strip()},DEV={dev_num.strip()}"
                            friendly_name = f"{card_label.strip()} ({dev_label.strip()})"
                            sound_cards.append((dev_id, friendly_name, dev_id))
            except Exception as e:
                log.debug(f"PushToTalk: arecord -l query error: {e}")

    # Deduplicate sound cards by ID
    unique_cards = []
    seen_ids = set()
    for card_id, label, desc in sound_cards:
        if card_id not in seen_ids:
            seen_ids.add(card_id)
            unique_cards.append((card_id, label, desc))

    return unique_cards


def get_audio_devices_list_windows():
    """Get list of audio devices on Windows."""

    ffmpeg_bin = get_ffmpeg_path()
    if not ffmpeg_bin:
        return []
    ffmpeg_args = "-f dshow -list_devices true -hide_banner -i dummy"
    args = [ffmpeg_bin] + shlex.split(ffmpeg_args)

    # dshow list_devices may output either individual devices tagged with '(audio)', e.g.:
    # [dshow @ 00000137146e4800] "Microphone (HD Pro Webcam)" (audio)
    # or all audio devices grouped after a 'DirectShow audio devices' heading, e.g.:
    # [dshow @ 02cec400] DirectShow audio devices
    # [dshow @ 02cec400]  "Desktop Microphone (3- Studio -"
    # [dshow @ 02cec400]     Alternative name "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\Desktop Microphone (3- Studio -"
    grouped_output_version = False

    av_device_lines = []
    with Popen(args=args, stdout=PIPE, stderr=PIPE) as proc:
        command_output = proc.stderr.read()
        for line in command_output.splitlines():
            line = line.decode('utf-8')

            # Start by optimistically adding all (audio) lines, regardless of mode.
            # What could possibly go wrong? right?
            if line.endswith("(audio)"):
                av_device_lines.append(line)
            # If at some point we find the audio header, we switch mode.
            elif "DirectShow audio devices" in line:
                grouped_output_version = True
            # In grouped mode, add lines that should have device names (skip input file errors).
            elif grouped_output_version:
                if "Alternative name" not in line and "Error" not in line:
                    av_device_lines.append(line)

    # Extract the device names from the lines.
    sound_cards = []
    for av_device_line in av_device_lines:
        names_within_quotes = re.findall(r'"(.+?)"', av_device_line)
        if len(names_within_quotes) == 1:
            device_str = names_within_quotes[0]
            sound_cards.append((device_str, device_str, device_str))
        else:
            # Keep it for the user to see, it might help them figure out their audio setup.
            sound_cards.append(("ptt parse error", "ptt parse error",
                                f"error parsing entry '{av_device_line}'"))

    # Output an EnumProperty list of tuples, e.g.:
    # [("Microphone (HD Pro Webcam)", "Microphone (HD Pro Webcam)", "Microphone (HD Pro Webcam)"), ...]
    # On Windows, the same str is repeated as that's the only thing we could find of useful.
    return sound_cards


def populate_enum_items_for_sound_devices(self, context):
    """Query the system for available audio devices and populate enum items."""

    # Re-use the existing enum values if they weren't generated too long ago.
    # Note: this generate function is called often, on draw of the UI element
    # that renders the enum property and per each enum item when the dropdown
    # is expanded.
    # To avoid bogging down the UI render pass, we avoid calling this function
    # too often, but we still want to call it occasionally, in case the user
    # plugs in a new audio device while Blender is running.
    try:
        last_executed = populate_enum_items_for_sound_devices.last_executed
        if (time.time() - last_executed) < 5:  # seconds
            return populate_enum_items_for_sound_devices.enum_items
    except AttributeError:
        # First time that the enum is being generated.
        pass

    log.debug("Polling system sound cards to update audio input drop-down")

    # Detect existing sound cards and devices
    if os_platform == 'Linux':
        sound_cards = get_audio_devices_list_linux()
    elif os_platform == 'Windows':
        sound_cards = get_audio_devices_list_windows()
    else:
        sound_cards = []

    # If nothing was detected, show it explicitly to the user instead of an empty dropdown.
    if not sound_cards:
        sound_cards = [NO_DEVICE]

    # Update the cached enum items and the generation timestamp
    populate_enum_items_for_sound_devices.enum_items = sound_cards
    populate_enum_items_for_sound_devices.last_executed = time.time()

    log.debug(f"Scanned & found sound devices: {populate_enum_items_for_sound_devices.enum_items}")
    return populate_enum_items_for_sound_devices.enum_items


def save_sound_card_preference(self, context):
    """Sync the chosen audio device to the user preferences.

    Called when the enum property is set.
    Sync the chosen audio device from the UI enum to the persisted user
    preferences according to the current OS.
    """

    addon_prefs = context.preferences.addons[ADDON_ID].preferences
    audio_device = addon_prefs.audio_input_device

    log.debug(f"Set audio input preference to '{audio_device}' for {os_platform}")

    if os_platform == 'Linux':
        addon_prefs.audio_device_linux = audio_device
    elif os_platform == 'Windows':
        addon_prefs.audio_device_windows = audio_device


# Operator #########################################################################################


class SEQUENCER_OT_push_to_talk(Operator):
    bl_idname = "sequencer.push_to_talk"
    bl_label = "Start Recording"
    bl_description = "Add a sound strip with audio recorded from the microphone"
    bl_options = {'UNDO', 'REGISTER'}

    # Runtime state shared between instances of this operator
    should_stop = False
    is_running = False
    visual_feedback_strip = None
    strip_channel = 1

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.filepath: str = ""
        self.recording_process = None
        self._timer = None
        self.was_playing = None
        self.frame_start = None

    def add_visual_feedback_strip(self, context):
        """Add a color strip to mark the current progress of the recording."""

        addon_prefs = context.preferences.addons[ADDON_ID].preferences
        scene = context.scene
        strips = scene.sequence_editor.strips if USE_STRIPS else scene.sequence_editor.sequences

        self.frame_start = scene.frame_current

        strip_data = {
            "name": "Recording...",
            "type": 'COLOR',
            "channel": addon_prefs.default_channel,  # Blender creates the channel or moves the strip if it is full.
            "frame_start": self.frame_start,
        }
        if bpy.app.version[0] >= 5:
            strip_data["length"] = 1
        else:
            strip_data["frame_end"] = self.frame_start + 1
        strip = strips.new_effect(**strip_data)
        strip.color = (0.5607842206954956, 0.21560697257518768, 0.1903851181268692)
        strip.blend_alpha = 0.0

        SEQUENCER_OT_push_to_talk.visual_feedback_strip = strip

    @classmethod
    def poll(cls, context):
        # Disable the record button and provide user information if there is a problem.
        # Note: see also the errors shown in the configuration panel. Many overlap.

        if os_platform not in supported_platforms:
            cls.poll_message_set(f"recording not supported on {os_platform}")
            return False

        if os_platform == 'Linux':
            has_recorder = bool(
                shutil.which("pw-record") or shutil.which("arecord") or get_ffmpeg_path(context)
            )
            if not has_recorder:
                cls.poll_message_set("No audio recorder found (pw-record, arecord, or ffmpeg)")
                return False
        else:  # Windows
            if not get_ffmpeg_path(context):
                cls.poll_message_set("ffmpeg not found (configure in Preferences or use One-Click Setup)")
                return False

        addon_prefs = context.preferences.addons[ADDON_ID].preferences
        if addon_prefs.audio_input_device == NO_DEVICE:
            cls.poll_message_set("no audio device found. Is there a microphone plugged in?")
            return False

        if context.scene.sync_mode != 'AUDIO_SYNC':
            cls.poll_message_set(
                "Playback mode should be set to 'Sync to Audio'\n"
                "Other modes lead to timing issues.\n\n"
                "Go to: Timeline Editor > Playback > Sync"
            )
            return False

        sounds_dir_sys = bpy.path.abspath(addon_prefs.sounds_dir)
        success, error_msg = SEQUENCER_OT_push_to_talk.check_sounds_dir(sounds_dir_sys)
        if not success:
            dir_str = sounds_dir_sys if sounds_dir_sys else addon_prefs.sounds_dir
            cls.poll_message_set(
                f"Can not save audio files to '{dir_str}'\n"
                f"{error_msg}\n\n"
                "Configure the folder in the Sequencer's sidebar > Push to Talk")
            return False

        # This operator is available only in the sequencer area of the sequence editor.
        return context.space_data.type == 'SEQUENCE_EDITOR' and (
            context.space_data.view_type == 'SEQUENCER'
            or context.space_data.view_type == 'SEQUENCER_PREVIEW'
        )

    @classmethod
    def check_sounds_dir(cls, sounds_dir_sys) -> tuple[bool, str]:
        """Returns a user message if there is a problem with the audio file directory."""

        # Resolve possible paths relative to the blend file to a system path.
        if not os.path.isdir(sounds_dir_sys):
            if bpy.path.abspath('//') == '':
                reason = ".blend file needs to be saved so the sound clips go in the same directory"
            else:
                reason = f"directory to save the sound clips does not exist: '{sounds_dir_sys}'"
            return False, reason

        if not os.access(sounds_dir_sys, os.W_OK):
            return False, "the directory to save the sound clips is not writable"

        return True, ""

    def generate_filename(self, context) -> tuple[bool, str]:
        """Create a filename for the sound file. Returns False and a user message if problemo."""

        addon_prefs = context.preferences.addons[ADDON_ID].preferences

        # Resolve possible paths relative to the blend file to a system path.
        sounds_dir_sys = bpy.path.abspath(addon_prefs.sounds_dir)
        success, error_msg = SEQUENCER_OT_push_to_talk.check_sounds_dir(sounds_dir_sys)
        if not success:
            return False, error_msg

        timestamp = datetime.datetime.now().strftime("_%Y-%m-%d_%H-%M-%S")

        self.filepath = f"{sounds_dir_sys}{addon_prefs.prefix}{timestamp}.wav"

        if os.path.exists(self.filepath):
            reason = f"a file already exists where the sound clip would be saved: {self.filepath}"
            return False, reason

        return True, ""

    def start_recording(self, context) -> bool:
        """Start a process to record audio."""

        addon_prefs = context.preferences.addons[ADDON_ID].preferences
        audio_device = addon_prefs.audio_input_device

        channels = str(addon_prefs.audio_channels)
        rate = str(addon_prefs.audio_sample_rate)
        depth = str(addon_prefs.audio_bit_depth)


        pw_record_bin = shutil.which("pw-record")
        arecord_bin = shutil.which("arecord")
        ffmpeg_bin = get_ffmpeg_path(context)

        # Mapping formats for each recorder
        pw_format_map = {'16': 's16', '24': 's24', '32': 'f32'}
        alsa_format_map = {'16': 'S16_LE', '24': 'S24_LE', '32': 'FLOAT_LE'}
        ffmpeg_codec_map = {'16': 'pcm_s16le', '24': 'pcm_s24le', '32': 'pcm_f32le'}

        pw_fmt = pw_format_map.get(depth, 's16')
        alsa_fmt = alsa_format_map.get(depth, 'S16_LE')
        ffmpeg_codec = ffmpeg_codec_map.get(depth, 'pcm_s16le')

        if os_platform == 'Linux':
            # 1. Native PipeWire recorder (handles USB microphones and sound servers without ALSA busy errors)
            if pw_record_bin:
                args = [
                    pw_record_bin,
                    f"--channels={channels}",
                    f"--rate={rate}",
                    f"--format={pw_fmt}",
                ]
                if audio_device and audio_device != 'default':
                    args.extend(["--target", str(audio_device)])
                args.append(self.filepath)

            # 2. Native ALSA recorder
            elif arecord_bin:
                args = [
                    arecord_bin,
                    "-D", str(audio_device or "default"),
                    "-c", str(channels),
                    "-r", str(rate),
                    "-f", alsa_fmt,
                ]
                args.append(self.filepath)

            # 3. FFmpeg fallback
            elif ffmpeg_bin:
                args = [
                    ffmpeg_bin, "-y",
                    "-f", "alsa",
                    "-i", str(audio_device or "default"),
                    "-ac", str(channels),
                    "-ar", str(rate),
                    "-c:a", ffmpeg_codec,
                ]
                args.extend(["-blocksize", "2048", "-flush_packets", "1", self.filepath])

            else:
                self.report({'ERROR'}, "No audio recording utility found (pw-record, arecord, or ffmpeg)")
                return False

        else:  # 'Windows'
            if not ffmpeg_bin:
                self.report({'ERROR'}, "FFmpeg not found. Please install or configure FFmpeg in Add-on Preferences.")
                return False
            args = [
                ffmpeg_bin, "-y",
                "-f", "dshow",
                "-i", f"audio={audio_device}",
                "-ac", str(channels),
                "-ar", str(rate),
                "-c:a", ffmpeg_codec,
            ]
            args.extend(["-blocksize", "2048", "-flush_packets", "1", self.filepath])

        log.debug(f"PushToTalk: Starting recording process: {args}")
        try:
            self.recording_process = Popen(args, stderr=PIPE, stdout=PIPE)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to start recording process: {e}")
            return False

        # Verify the process didn't exit immediately due to bad parameters/device
        time.sleep(0.08)
        if self.recording_process.poll() is not None:
            err_msg = ""
            if self.recording_process.stderr:
                err_msg = self.recording_process.stderr.read().decode('utf-8', errors='replace').strip()
            log.error(f"PushToTalk: Recording process failed immediately ({self.recording_process.returncode}): {err_msg}")
            self.report(
                {'ERROR'},
                f"Recording failed to start (exit code {self.recording_process.returncode}): {err_msg[:120]}"
            )
            self.recording_process = None
            return False

        log.debug("PushToTalk: Started audio recording process")
        log.debug(f"PushToTalk: {args}")
        return True

    def invoke(self, context, event):
        """Called when this operator is starting."""

        log.debug("PushToTalk: invoke")

        # If this operator is already running modal, this second invocation is
        # the toggle to stop it. Set a variable that the first modal operator
        # instance will listen to in order to terminate.
        if SEQUENCER_OT_push_to_talk.is_running:
            SEQUENCER_OT_push_to_talk.should_stop = True
            return {'FINISHED'}

        SEQUENCER_OT_push_to_talk.is_running = True

        # Generate the name to save the audio file.
        success, error_msg = self.generate_filename(context)
        if not success:
            SEQUENCER_OT_push_to_talk.is_running = False
            self.report({'ERROR'}, f"Could not record audio: {error_msg}")
            return {'CANCELLED'}

        # Start the audio recording sub-process.
        if not self.start_recording(context):
            SEQUENCER_OT_push_to_talk.is_running = False
            return {'CANCELLED'}

        # If the playhead is about to loop, go already to the beginning before
        # starting the recording. Otherwise, since the behaviour when recording
        # is to stop at the end of the frame range, it would result in a 1 frame
        # strip with not enough time to start the recording process.
        if context.scene.frame_current >= context.scene.frame_end - 1:
            context.scene.frame_current = context.scene.frame_start

        # Add visual feedback that the recording is in progress.
        self.add_visual_feedback_strip(context)

        # Ensure that the timeline is playing
        self.was_playing = context.screen.is_animation_playing
        if not self.was_playing:
            bpy.ops.screen.animation_play()

        # Start this operator as modal
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.02, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        """Periodic update to draw and check if this operator should stop."""

        # Cancel. Delete the current recording.
        if event.type in {'ESC'}:
            self.cancel(context)
            return {'CANCELLED'}

        # Confirm. Create a strip with the current recording.
        if event.type in {'RET'}:
            return self.execute(context)

        # Periodic update
        if event.type == 'TIMER':
            # Listen for signal to stop
            if SEQUENCER_OT_push_to_talk.should_stop:
                return self.execute(context)
            # Stop if the timeline was paused
            if not context.screen.is_animation_playing:
                self.was_playing = True
                return self.execute(context)
            # Stop if the timeline is about to loop around
            if context.scene.frame_current >= context.scene.frame_end:
                return self.execute(context)
            # Stop if the user deletes the visual feedback strip
            color_strip = SEQUENCER_OT_push_to_talk.visual_feedback_strip
            if not color_strip:
                return self.cancel(context)

        # Don't consume the input, otherwise it is impossible to click the stop button.
        return {'PASS_THROUGH'}

    def on_cancel_or_finish(self, context):
        """Called when this operator is finishing (confirm) or got canceled."""

        # Unregister from the periodic modal calls.
        if self._timer:
            wm = context.window_manager
            wm.event_timer_remove(self._timer)

        # Restore the play state (stop it if it wasn't running).
        # Do this before terminating the recording so that the new sound strip doesn't look shorter
        # than the playhead position which would continue while waiting for ffmpeg to finish.
        if not self.was_playing:
            bpy.ops.screen.animation_play()

        # Finish the sound recording process.
        if self.recording_process:
            if os_platform == 'Windows':
                self.recording_process.terminate()
            else:
                try:
                    self.recording_process.send_signal(signal.SIGINT)
                except Exception:
                    self.recording_process.terminate()

            # The maximum amount of time for us to wait for recorder to shut down in seconds.
            maximum_shutdown_wait_time = 3
            try:
                self.recording_process.wait(maximum_shutdown_wait_time)
            except TimeoutExpired:
                log.warning(
                    f"Recording process did not gracefully shutdown within {maximum_shutdown_wait_time}s. Killing."
                )
                self.recording_process.kill()
                try:
                    self.recording_process.wait(1)
                except Exception:
                    pass
            self.recording_process = None

        # Remove the temporary visual feedback strip.
        color_strip = SEQUENCER_OT_push_to_talk.visual_feedback_strip
        if color_strip and color_strip.name:
            sequence_ed = context.scene.sequence_editor
            strips = sequence_ed.strips if USE_STRIPS else sequence_ed.sequences

            SEQUENCER_OT_push_to_talk.visual_feedback_strip = None
            strips.remove(color_strip)

        # Update this operator's state.
        SEQUENCER_OT_push_to_talk.is_running = False
        SEQUENCER_OT_push_to_talk.should_stop = False

    def execute(self, context):
        """Called to finish this operator's action.

        Create the sound strip with the finished audio recording.
        """

        log.debug("PushToTalk: execute")

        # Cleanup execution state
        self.on_cancel_or_finish(context)

        # Validate that audio was actually recorded and is not an empty file
        if not os.path.isfile(self.filepath) or os.path.getsize(self.filepath) <= 44:
            log.error(f"PushToTalk: Audio file missing or empty at {self.filepath}")
            self.report(
                {'ERROR'},
                f"Recording failed: No audio data captured to '{self.filepath}'. "
                "Please verify your microphone connection."
            )
            try:
                if os.path.isfile(self.filepath):
                    os.remove(self.filepath)
            except Exception:
                pass
            return {'CANCELLED'}

        addon_prefs = context.preferences.addons[ADDON_ID].preferences
        sequence_ed = context.scene.sequence_editor
        strips = sequence_ed.strips if USE_STRIPS else sequence_ed.sequences

        # Create a new sound strip in the place of the dummy strip.
        name = addon_prefs.prefix
        start_frame = self.frame_start if self.frame_start is not None else context.scene.frame_current
        sound_strip = strips.new_sound(
            name, self.filepath, self.strip_channel, start_frame
        )

        return {'FINISHED'}

    def cancel(self, context):
        """Cleanup temporary state if canceling during modal execution."""

        log.debug("PushToTalk: cancel")

        # Cleanup execution state
        self.on_cancel_or_finish(context)

        # If the timeline wasn't playing, restore the playhead to the original position.
        if not self.was_playing:
            scene = context.scene
            scene.frame_current = self.frame_start

    @classmethod
    def update_on_main_thread(cls):
        """Ticks even when the operator is not running. Needed to safely access the color strip."""

        delta_s = 0.05  # Update frequency

        color_strip = SEQUENCER_OT_push_to_talk.visual_feedback_strip

        # If the color_strip is None, the operator isn't running. Nothing to do.
        if not color_strip:
            return delta_s

        # Check if the color strip got deleted by Blender. Signal the operator to stop.
        if not color_strip.name:
            # Cleanly set our reference to None, which can be checked in modal().
            # Accessing the strip directly in modal() is not thread safe.
            SEQUENCER_OT_push_to_talk.visual_feedback_strip = None
            return delta_s

        # Increase the visual feedback strip's size.
        current_frame = bpy.context.scene.frame_current
        if hasattr(color_strip, "duration") and hasattr(color_strip, "frame_start"):
            color_strip.duration = max(1, current_frame - int(color_strip.frame_start))
        else:
            color_strip.frame_final_end = current_frame

        # Keep track of the current channel for the recorded strip.
        # In case the color strip gets deleted, we have up-to-date info.
        SEQUENCER_OT_push_to_talk.strip_channel = color_strip.channel

        return delta_s


# UI ###############################################################################################


def draw_push_to_talk_button(self, context):
    # Show only in the sequencer area (not on the preview area).
    if (
        context.space_data.view_type != 'SEQUENCER'
        and context.space_data.view_type != 'SEQUENCER_PREVIEW'
    ):
        return

    layout = self.layout
    if SEQUENCER_OT_push_to_talk.is_running:
        # 'SNAP_FACE' is used because it looks like 'STOP', which was removed.
        layout.operator("sequencer.push_to_talk", text="Stop Recording", icon='SNAP_FACE')
    else:
        layout.operator("sequencer.push_to_talk", text="Start Recording", icon='RECORD_ON')


class SEQUENCER_PT_push_to_talk(Panel):
    bl_label = "Configuration"
    bl_category = "Push To Talk"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'

    @classmethod
    def poll(cls, context):
        # Show this panel only in the sequence editor in the right-side panel
        # of the sequencer area (not on the preview area).
        return context.space_data.type == 'SEQUENCE_EDITOR' and (
            context.space_data.view_type == 'SEQUENCER'
            or context.space_data.view_type == 'SEQUENCER_PREVIEW'
        )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        # Disable the configuration panel and provide user information if there is a problem.
        # Note: see also the errors shown in the operator poll(). Many overlap.
        problem_found = ""
        ffmpeg_bin = get_ffmpeg_path(context)
        if os_platform not in supported_platforms:
            problem_found = f"Recording on {os_platform} is not supported"
        elif os_platform == 'Windows' and not ffmpeg_bin:
            problem_found = "ffmpeg not found"
        elif os_platform == 'Linux':
            has_recorder = bool(
                shutil.which("pw-record") or shutil.which("arecord") or ffmpeg_bin
            )
            if not has_recorder:
                problem_found = "No audio recorder found (pw-record, arecord, or ffmpeg)"

        col = layout.column()
        if problem_found:
            col.label(text=problem_found, icon='ERROR')
            if not ffmpeg_bin and os_platform in supported_platforms:
                col.operator(
                    "sequencer.push_to_talk_setup_ffmpeg",
                    text="Download & Setup FFmpeg",
                    icon='IMPORT',
                )
            col = col.column()
            col.enabled = False

        addon_prefs = context.preferences.addons[ADDON_ID].preferences

        col.prop(addon_prefs, "prefix")
        col.prop(addon_prefs, "sounds_dir")
        sounds_dir_sys = bpy.path.abspath(addon_prefs.sounds_dir)
        success, error_msg = SEQUENCER_OT_push_to_talk.check_sounds_dir(sounds_dir_sys)
        if not success:
            row = col.row()
            row.alignment = 'RIGHT'
            row.alert = True
            row.label(text=error_msg, icon='ERROR')

        col.separator()
        col.prop(addon_prefs, "default_channel")

        col.separator()
        col.prop(addon_prefs, "audio_input_device")

        col.separator()
        quality_box = col.box()
        quality_box.label(text="Audio Quality & Latency", icon='SOUND')
        q_col = quality_box.column(align=True)
        q_col.prop(addon_prefs, "audio_channels")
        q_col.prop(addon_prefs, "audio_sample_rate")
        q_col.prop(addon_prefs, "audio_bit_depth")


        bitrate_info = get_effective_bitrate_info(
            addon_prefs.audio_channels,
            addon_prefs.audio_sample_rate,
            addon_prefs.audio_bit_depth,
        )
        q_col.separator()
        info_row = q_col.row()
        info_row.alignment = 'RIGHT'
        info_row.label(text=f"Bitrate: {bitrate_info}", icon='INFO')
        # DEBUG
        # col.prop(addon_prefs, "audio_device_linux", text="(linux Debug)")
        # col.prop(addon_prefs, "audio_device_windows", text="(Win Debug)")

        # Show a save button for the user preferences if they aren't automatically saved.
        prefs = context.preferences
        if not prefs.use_preferences_save:
            col.separator()
            col.operator(
                "wm.save_userpref",
                text=f"Save Preferences{' *' if prefs.is_dirty else ''}",
            )


# FFmpeg Setup State & Operators ###################################################################


class SetupFFmpegState:
    is_running: bool = False
    progress: float = 0.0
    status_message: str = ""
    error_message: str = ""
    success_message: str = ""


class SEQUENCER_OT_push_to_talk_setup_ffmpeg(Operator):
    bl_idname = "sequencer.push_to_talk_setup_ffmpeg"
    bl_label = "Download & Setup FFmpeg"
    bl_description = "Download and configure a standalone static build of FFmpeg automatically"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        if SetupFFmpegState.is_running:
            self.report({'INFO'}, "FFmpeg download is already in progress.")
            return {'CANCELLED'}

        if hasattr(bpy.app, "online_access") and not bpy.app.online_access:
            self.report(
                {'ERROR'},
                "Online access is disabled in Blender. Enable it in Preferences > System > Network."
            )
            return {'CANCELLED'}

        if os_platform not in {'Linux', 'Windows'}:
            self.report({'ERROR'}, f"One-click FFmpeg download is not supported on {os_platform}.")
            return {'CANCELLED'}

        SetupFFmpegState.is_running = True
        SetupFFmpegState.progress = 0.0
        SetupFFmpegState.status_message = "Initializing download..."
        SetupFFmpegState.error_message = ""
        SetupFFmpegState.success_message = ""

        # Start download thread
        thread = threading.Thread(target=self._download_worker, daemon=True)
        thread.start()

        # Register UI redraw timer
        bpy.app.timers.register(self._update_timer, persistent=True)

        self.report({'INFO'}, "Starting FFmpeg download in the background...")
        return {'FINISHED'}

    @classmethod
    def _update_timer(cls):
        # Trigger redraw of Preferences area and Sequencer areas
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type in {'PREFERENCES', 'SEQUENCE_EDITOR'}:
                    area.tag_redraw()

        if SetupFFmpegState.is_running:
            return 0.1  # continue timer every 100ms

        # When finished or failed:
        if SetupFFmpegState.success_message:
            try:
                addon_prefs = bpy.context.preferences.addons[ADDON_ID].preferences
                target_bin = os.path.join(
                    addon_dir, "bin", "ffmpeg.exe" if os_platform == 'Windows' else "ffmpeg"
                )
                if os.path.isfile(target_bin):
                    addon_prefs.ffmpeg_custom_path = target_bin
            except Exception as e:
                log.error(f"Error updating preferences after FFmpeg setup: {e}")

        return None  # Stop timer

    @classmethod
    def _download_worker(cls):
        try:
            bin_dir = os.path.join(addon_dir, "bin")
            os.makedirs(bin_dir, exist_ok=True)

            if os_platform == 'Linux':
                # Official static GPL build from BtbN
                url = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linux64-gpl.tar.xz"
                archive_name = "ffmpeg_download.tar.xz"
                bin_name = "ffmpeg"
            else:  # Windows
                url = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
                archive_name = "ffmpeg_download.zip"
                bin_name = "ffmpeg.exe"

            archive_path = os.path.join(bin_dir, archive_name)
            target_bin = os.path.join(bin_dir, bin_name)

            SetupFFmpegState.status_message = "Connecting to server..."
            req = urllib.request.Request(
                url,
                headers={"User-Agent": f"Mozilla/5.0 ({os_platform}) Blender-PushToTalk"}
            )

            with urllib.request.urlopen(req, timeout=30) as response, open(archive_path, "wb") as out_file:
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                chunk_size = 512 * 1024  # 512 KB chunks

                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    out_file.write(chunk)
                    downloaded += len(chunk)

                    if total_size > 0:
                        SetupFFmpegState.progress = downloaded / total_size
                        pct = int(SetupFFmpegState.progress * 100)
                        down_mb = downloaded / (1024 * 1024)
                        tot_mb = total_size / (1024 * 1024)
                        SetupFFmpegState.status_message = f"Downloading: {pct}% ({down_mb:.1f}/{tot_mb:.1f} MB)"
                    else:
                        down_mb = downloaded / (1024 * 1024)
                        SetupFFmpegState.status_message = f"Downloading: {down_mb:.1f} MB"

            SetupFFmpegState.status_message = "Extracting FFmpeg..."
            SetupFFmpegState.progress = 1.0

            # Extract executable from archive
            if os_platform == 'Linux':
                with tarfile.open(archive_path, "r:xz") as tar:
                    found = False
                    for member in tar.getmembers():
                        if member.name.endswith("/bin/ffmpeg") or member.name == "ffmpeg" or member.name.endswith("/ffmpeg"):
                            f = tar.extractfile(member)
                            if f:
                                with open(target_bin, "wb") as dest:
                                    shutil.copyfileobj(f, dest)
                                found = True
                                break
                    if not found:
                        raise RuntimeError("Could not find 'ffmpeg' binary inside the downloaded archive.")
            else:  # Windows
                with zipfile.ZipFile(archive_path, "r") as zf:
                    found = False
                    for name in zf.namelist():
                        if name.endswith("/bin/ffmpeg.exe") or name.endswith("ffmpeg.exe"):
                            with zf.open(name) as src, open(target_bin, "wb") as dst:
                                shutil.copyfileobj(src, dst)
                            found = True
                            break
                    if not found:
                        raise RuntimeError("Could not find 'ffmpeg.exe' inside the downloaded zip archive.")

            # Make binary executable
            if os_platform != 'Windows':
                current_mode = os.stat(target_bin).st_mode
                os.chmod(target_bin, current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

            # Remove downloaded archive to save disk space
            try:
                if os.path.exists(archive_path):
                    os.remove(archive_path)
            except Exception:
                pass

            # Verify binary executes
            test_proc = Popen([target_bin, "-version"], stdout=PIPE, stderr=PIPE)
            test_proc.communicate(timeout=5)
            if test_proc.returncode != 0:
                raise RuntimeError(f"FFmpeg verification failed with exit code {test_proc.returncode}")

            SetupFFmpegState.success_message = f"FFmpeg ready: {target_bin}"
            SetupFFmpegState.status_message = "Setup complete!"
            log.info(f"PushToTalk: Successfully installed FFmpeg to {target_bin}")

        except Exception as err:
            log.error(f"PushToTalk: FFmpeg setup failed: {err}")
            SetupFFmpegState.error_message = f"Setup failed: {err}"
            SetupFFmpegState.status_message = ""
        finally:
            SetupFFmpegState.is_running = False


class SEQUENCER_OT_push_to_talk_reset_ffmpeg_path(Operator):
    bl_idname = "sequencer.push_to_talk_reset_ffmpeg_path"
    bl_label = "Reset to Auto-detect"
    bl_description = "Clear custom path and use system or bundled FFmpeg"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        addon_prefs = context.preferences.addons[ADDON_ID].preferences
        addon_prefs.ffmpeg_custom_path = ""
        self.report({'INFO'}, "Reset FFmpeg path to auto-detection.")
        return {'FINISHED'}


# Settings #########################################################################################


class SEQUENCER_PushToTalk_Preferences(AddonPreferences):
    bl_idname = ADDON_ID

    def update_ffmpeg_path(self, context):
        if hasattr(populate_enum_items_for_sound_devices, "last_executed"):
            delattr(populate_enum_items_for_sound_devices, "last_executed")

    ffmpeg_custom_path: StringProperty(
        name="Custom FFmpeg Path",
        description="Custom path to the ffmpeg executable (leave empty for auto-detection)",
        default="",
        subtype='FILE_PATH',
        update=update_ffmpeg_path,
    )

    prefix: StringProperty(
        name="Name Prefix",
        description="A label to name the created sound strips and files",
        default="temp_dialog",
    )

    # Blender 4.5+ requires props to explicitly declare support for using "//" for
    # paths relative to the blend file.
    sounds_dir_prop_options = set()
    if (bpy.app.version[0] == 4 and bpy.app.version[1] >= 5) or bpy.app.version[0] >= 5:
        sounds_dir_prop_options = {'PATH_SUPPORTS_BLEND_RELATIVE'}

    sounds_dir: StringProperty(
        name="Sounds Dir",
        description="Directory where to save the generated audio files",
        default="//",
        subtype="DIR_PATH",
        options=sounds_dir_prop_options,
    )

    default_channel: IntProperty(
        name="Channel",
        description="Sequencer channel where to add the audio strips. "
                    "If a strip does not fit, it goes in the next available channel.",
        default=1,
        min=1,
        max=128,  # MAX_CHANNELS in Blender's source.
    )

    # Explicitly save an audio configuration per platform in case the same user uses Blender in
    # different platforms and syncs user settings.
    audio_device_linux: StringProperty(
        name="Audio Input Device (Linux)",
        description="Hardware slot of the audio input device given by 'arecord -L'",
        default="default",
    )
    audio_device_windows: StringProperty(
        name="Audio Input Device (Windows)",
        description="Hardware slot of the audio input device given by 'ffmpeg'",
        default="setting not synced yet",
    )
    # The runtime audio device, depending on platform.
    audio_input_device: EnumProperty(
        items=populate_enum_items_for_sound_devices,
        name="Audio Input",
        description="Audio input device to be used, from the ones found on this computer",
        options={'SKIP_SAVE'},
        update=save_sound_card_preference,
    )

    audio_channels: EnumProperty(
        items=[
            ('1', "Mono (1 Channel)", "Single channel audio recording (recommended for voice/dialog)"),
            ('2', "Stereo (2 Channels)", "Dual channel audio recording (left and right channels)"),
        ],
        name="Channels",
        description="Number of audio channels to record",
        default='1',
    )

    audio_sample_rate: EnumProperty(
        items=[
            ('16000', "16 kHz (Voice / Speech)", "Low bandwidth, speech-optimized (16,000 Hz)"),
            ('22050', "22.05 kHz (Low Quality)", "Reduced frequency bandwidth (22,050 Hz)"),
            ('44100', "44.1 kHz (CD Quality)", "Standard CD audio quality (44,100 Hz)"),
            ('48000', "48 kHz (Video / Broadcast)", "Standard broadcast and video sample rate (48,000 Hz)"),
            ('96000', "96 kHz (High-Res Studio)", "High-resolution studio recording (96,000 Hz)"),
            ('192000', "192 kHz (Ultra High-Res)", "Maximum fidelity studio recording (192,000 Hz)"),
        ],
        name="Sample Rate",
        description="Audio sample rate in Hertz (Hz)",
        default='48000',
    )

    audio_bit_depth: EnumProperty(
        items=[
            ('16', "16-bit (Standard PCM)", "16-bit integer PCM uncompressed (standard dynamic range ~96 dB)"),
            ('24', "24-bit (Studio PCM)", "24-bit integer PCM uncompressed (professional dynamic range ~144 dB)"),
            ('32', "32-bit (Float High-Res)", "32-bit floating point uncompressed (maximum fidelity, clip-resistant)"),
        ],
        name="Bit Depth",
        description="Audio bit depth resolution",
        default='16',
    )


    def draw(self, context):
        layout = self.layout

        # --- FFmpeg Configuration Section ---
        box = layout.box()
        box_row = box.row()
        box_row.label(text="FFmpeg Configuration", icon='PREFERENCES')

        resolved_ffmpeg = get_ffmpeg_path(context)
        is_custom = bool(self.ffmpeg_custom_path.strip())

        # Status row
        status_box = box.box()
        if resolved_ffmpeg:
            status_row = status_box.row()
            status_row.label(text=f"FFmpeg Active: {resolved_ffmpeg}", icon='CHECKMARK')
            if is_custom:
                status_box.label(text="Source: User-specified custom path.", icon='INFO')
            elif os.path.join(addon_dir, "bin") in resolved_ffmpeg:
                status_box.label(text="Source: Add-on managed standalone binary.", icon='INFO')
            else:
                status_box.label(text="Source: System PATH.", icon='INFO')
        else:
            status_row = status_box.row()
            status_row.alert = True
            status_row.label(text="FFmpeg Not Found! Recording requires FFmpeg.", icon='ERROR')
            status_box.label(text="Specify a custom path below or use One-Click Setup.", icon='INFO')

        # Custom Path input
        path_box = box.column(align=True)
        path_row = path_box.row(align=True)
        path_row.prop(self, "ffmpeg_custom_path")
        if is_custom:
            path_row.operator(
                "sequencer.push_to_talk_reset_ffmpeg_path",
                text="",
                icon='X',
            )

        if is_custom and not is_executable_file(bpy.path.abspath(self.ffmpeg_custom_path).strip()):
            err_row = path_box.row()
            err_row.alert = True
            err_row.label(text="Specified path does not point to a valid executable file!", icon='ERROR')

        # One-Click Setup Button & Progress
        setup_col = box.column(align=True)
        if SetupFFmpegState.is_running:
            setup_box = setup_col.box()
            setup_box.label(
                text=SetupFFmpegState.status_message or "Downloading FFmpeg...",
                icon='TIME',
            )
        else:
            setup_row = setup_col.row()
            setup_row.scale_y = 1.2
            setup_row.operator(
                "sequencer.push_to_talk_setup_ffmpeg",
                text="Download & Setup FFmpeg (One-Click)",
                icon='IMPORT',
            )
            if SetupFFmpegState.error_message:
                err_box = setup_col.box()
                err_box.alert = True
                err_box.label(text=SetupFFmpegState.error_message, icon='CANCEL')
            elif SetupFFmpegState.success_message:
                succ_box = setup_col.box()
                succ_box.label(text=SetupFFmpegState.success_message, icon='CHECKMARK')



        # Save button if auto-save is off
        prefs = context.preferences
        if not prefs.use_preferences_save:
            layout.separator()
            layout.operator(
                "wm.save_userpref",
                text=f"Save Preferences{' *' if prefs.is_dirty else ''}",
            )


# Add-on Registration ##############################################################################

classes = (
    SEQUENCER_OT_push_to_talk,
    SEQUENCER_OT_push_to_talk_setup_ffmpeg,
    SEQUENCER_OT_push_to_talk_reset_ffmpeg_path,
    SEQUENCER_PT_push_to_talk,
    SEQUENCER_PushToTalk_Preferences,
)


def register():
    log.debug("--------Registering Push to Talk---------------------")

    # Log warnings and continue without raising errors.
    # This add-on should keep on functioning and gracefully disable the interface for recording.
    if os_platform not in supported_platforms:
        log.warning(
            f"PushToTalk add-on is not supported on {os_platform}. Recording will not work."
        )
    if not get_ffmpeg_path():
        log.warning(
            "PushToTalk add-on could not find ffmpeg. Configure a custom path or use One-Click Setup in Preferences."
        )

    # Register as normal.
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.SEQUENCER_HT_header.append(draw_push_to_talk_button)

    bpy.app.timers.register(
        SEQUENCER_OT_push_to_talk.update_on_main_thread, persistent=True
    )  # Keep timer running across file loads

    # Sync system detected audio devices with the saved preferences
    addon_prefs = bpy.context.preferences.addons[ADDON_ID].preferences
    prop_rna = addon_prefs.rna_type.properties['audio_input_device']
    audio_input_devices = {
        'Linux': addon_prefs.audio_device_linux,
        'Windows': addon_prefs.audio_device_windows,
    }
    saved_setting_value = audio_input_devices.get(os_platform, "setting not synced yet")
    log.debug(f"Preferred device from user settings: \"{saved_setting_value}\"")

    audio_devices_found = populate_enum_items_for_sound_devices(prop_rna, bpy.context)
    assert audio_devices_found  # Should always have an option also when no device is found.

    found_preferred_mic = False
    for enum_item in audio_devices_found:
        if enum_item[0] == saved_setting_value:
            found_preferred_mic = True
            break

    if found_preferred_mic:
        # Set the runtime setting to the user setting.
        addon_prefs.audio_input_device = saved_setting_value
    else:
        # Log if the user setting got lost.
        if saved_setting_value != "setting not synced yet":
            log.info(
                f"Could not restore audio device user preference: "
                f"'{saved_setting_value}'. This can happen if the preferred audio device "
                f"is not currently connected."
            )
        # Set the runtime setting to the first audio device.
        # This will also update the user setting via the enum's update function.
        addon_prefs.audio_input_device = str(audio_devices_found[0][0])

    log.debug("--------Done Registering-----------------------------")


def unregister():
    log.debug("--------Unregistering Push to Talk-------------------")

    if bpy.app.timers.is_registered(SEQUENCER_OT_push_to_talk.update_on_main_thread):
        bpy.app.timers.unregister(SEQUENCER_OT_push_to_talk.update_on_main_thread)

    bpy.types.SEQUENCER_HT_header.remove(draw_push_to_talk_button)

    for cls in classes:
        bpy.utils.unregister_class(cls)

    log.debug("--------Done Unregistering---------------------------")


if __name__ == "__main__":
    register()
